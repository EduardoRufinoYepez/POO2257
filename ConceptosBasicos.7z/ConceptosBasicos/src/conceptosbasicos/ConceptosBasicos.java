/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conceptosbasicos;

import ico.fes.Automovil;
import java.awt.Color;
import static javafx.scene.paint.Color.color;

/**
 *
 * @author YO claro que si
 */
public class ConceptosBasicos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Automovil miBocho = new Automovil();
        miBocho.setMarc("VW");
        miBocho.setSubMarca("Sedan");
        miBocho.setModelo(1970);
        miBocho.setColor(Color.blue);
        System.out.println(miBocho);

        Automovil acura = new Automovil();
        acura.setMarc("acura");
        acura.setSubMarca("deportivo");
        acura.setModelo(2000);
        acura.setColor(Color.black);
        System.out.println(acura);

        Automovil mustang = new Automovil();
        mustang.setMarc("mustang");
        mustang.setSubMarca("deportivo");
        mustang.setModelo(2020);
        mustang.setColor(Color.green);
        System.out.println(mustang);

    }

}
