/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ico.fes;

import java.awt.Color;

/**
 *
 * @author YO claro que si
 */
public class Automovil {
    private String marc;
    private String subMarca;
    private int Modelo;
    private Color color;

    public Automovil() {
    }
    

    public Automovil(String marc, String subMarca, int Modelo, Color color) {
        this.marc = marc;
        this.subMarca = subMarca;
        this.Modelo = Modelo;
        this.color = color;
    }
    

    public String getMarc() {
        return marc;
    }

    public void setMarc(String marc) {
        this.marc = marc;
    }

    public String getSubMarca() {
        return subMarca;
    }

    public void setSubMarca(String subMarca) {
        this.subMarca = subMarca;
    }

    public int getModelo() {
        return Modelo;
    }

    public void setModelo(int Modelo) {
        this.Modelo = Modelo;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        System.out.println("Metiendo el auto al taller de pintura...");
        this.color = color;
    }

    @Override
    public String toString() {
        return "Automovil{" + "marc=" + marc + ", subMarca=" + subMarca + ", Modelo=" + Modelo + ", color=" + color + '}';
    }
    
    
    
    
}
